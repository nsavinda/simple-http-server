# simple-http-server-python
Simple HTTP server with PHP support

# Start Server

```python
python server.py
```

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 2728



# About 

Support for POST and GET requests 
Sopported Content-Type:application/x-www-form-urlencoded


# File Structure

```
├── htdocs/                        # Web site content
│   ├── index.html                 # Form
│   ├── add.php                    # Php code to add numbers
│
├── server.py                      # Main File 
```